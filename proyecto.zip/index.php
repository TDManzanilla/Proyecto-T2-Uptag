<?php
include ('app/config.php');

header('Location: '.APP_URL.'/login/logout.php');